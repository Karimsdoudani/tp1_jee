@WebServlet("/modifier")
public class ModificationServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Récupérer l'ID de l'étudiant à partir de l'URL
        int id = Integer.parseInt(request.getParameter("id"));
        
        // Récupérer les données de l'étudiant depuis la base de données
        Gestiondb g = new Gestiondb();
        Etudiant etudiant = g.getEtudiantById(id);
        
        // Stocker les données de l'étudiant dans la requête pour les envoyer à la page JSP
        request.setAttribute("etudiant", etudiant);
        
        // Rediriger vers la page modifier.jsp avec les données de l'étudiant
        RequestDispatcher rd = request.getRequestDispatcher("modifier.jsp");
        rd.forward(request, response);
    }
}
